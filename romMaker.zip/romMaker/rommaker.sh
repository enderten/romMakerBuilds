#!/bin/bash

set -e

BASE_DIR=$(pwd)
GSI_DIR="$BASE_DIR/gsi"
MOUNT_DIR="$BASE_DIR/mount"
NEW_DIR="$BASE_DIR/new"
OUT_DIR="$BASE_DIR/out"

clear

echo "RomMaker-GSI Extractor"
echo "----------------------"
echo "[1] Extract"
echo "[2] Make .IMG"
echo "[q] Exit"
echo

read -p "> " opt

case "$opt" in

1)
    read -p "Ruta del system.img (EXT4): " IMG

    if [ ! -f "$IMG" ]; then
        echo "IMG no encontrado"
        exit 1
    fi

    echo "[*] Preparando carpetas"
    mkdir -p "$GSI_DIR" "$MOUNT_DIR"

    echo "[*] Chequeando filesystem"
    sudo e2fsck -f "$IMG"

    echo "[*] Montando IMG"
    sudo mount -o loop "$IMG" "$MOUNT_DIR"

    echo "[*] Copiando contenido a gsi/"
    sudo cp -a "$MOUNT_DIR/." "$GSI_DIR/"

    echo "[*] Ajustando permisos"
    sudo chown -R "$USER:$USER" "$GSI_DIR"

    echo "[*] Desmontando"
    sudo umount "$MOUNT_DIR"

    echo
    echo "✔ Extract terminado"
    echo "✔ Todo quedó en ./gsi (editable)"
    ;;

2)
    echo "[*] Creando system-new.img (3.8 GB)"
    mkdir -p "$OUT_DIR" "$NEW_DIR"

    dd if=/dev/zero of="$OUT_DIR/system-new.img" bs=1M count=3890 status=progress

    echo "[*] Formateando EXT4"
    mkfs.ext4 "$OUT_DIR/system-new.img"

    echo "[*] Montando imagen nueva"
    sudo mount -o loop "$OUT_DIR/system-new.img" "$NEW_DIR"

    echo "[*] Copiando contenido desde gsi/"
    sudo cp -a "$GSI_DIR/." "$NEW_DIR/"
    sync

    echo "[*] Desmontando"
    sudo umount "$NEW_DIR"

    echo "[*] Ajustando filesystem"
    sudo e2fsck -f "$OUT_DIR/system-new.img"
    sudo resize2fs "$OUT_DIR/system-new.img"

    echo
    echo "system-new.img creado en ./out"
    ;;

q)
    exit 0
    ;;

*)
    echo "Opción inválida"
    ;;
esac
