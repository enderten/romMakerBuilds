import os
import sys

BASE = os.getcwd()
BOOT_DIR = os.path.join(BASE, "boot")
OUT_DIR = os.path.join(BASE, "out")

def run(cmd):
    print(f"> {cmd}")
    if os.system(cmd) != 0:
        print("ERROR executing command")
        sys.exit(1)

def clear():
    os.system("clear")

def menu():
    clear()
    print("RomMaker macOS (Limited)")
    print("------------------------")
    print("[1] Disable VBMeta (no verification)")
    print("[q] Exit\n")

# ---------- BOOT ----------

def extract_boot():
    img = input("Path to boot.img: ").strip()
    if not os.path.isfile(img):
        print("boot.img not found")
        return

    os.makedirs(BOOT_DIR, exist_ok=True)
    os.chdir(BOOT_DIR)

    # macOS-safe binary grep
    run(f"LC_ALL=C grep -abo $'\\x1f\\x8b\\x08' {img} | head -n1 > offset.txt")

    with open("offset.txt") as f:
        offset = f.read().split(":")[0].strip()

    if not offset.isdigit():
        print("No gzip ramdisk found (not supported on macOS)")
        sys.exit(1)

    print(f"[*] Ramdisk offset: {offset}")

    run(f"dd if={img} of=ramdisk.gz bs=1 skip={offset}")
    run("mkdir -p ramdisk")
    run("gzip -dc ramdisk.gz | (cd ramdisk && cpio -idmv)")

    os.chdir(BASE)
    input("\n✔ BOOT ramdisk extracted to ./boot/ramdisk — ENTER")

def repack_boot():
    ramdisk_path = os.path.join(BOOT_DIR, "ramdisk")
    if not os.path.isdir(ramdisk_path):
        print("No ramdisk directory found. Extract boot first.")
        return

    original = input("Path to original boot.img: ").strip()
    if not os.path.isfile(original):
        print("Original boot.img not found")
        return

    os.chdir(BOOT_DIR)

    run("find ramdisk | cpio -o -H newc | gzip > ramdisk-new.gz")

    run(f"LC_ALL=C grep -abo $'\\x1f\\x8b\\x08' {original} | head -n1 > offset.txt")
    with open("offset.txt") as f:
        offset = f.read().split(":")[0].strip()

    if not offset.isdigit():
        print("Failed to detect kernel size")
        sys.exit(1)

    print(f"[*] Kernel size: {offset}")

    run(f"dd if={original} of=kernel.bin bs=1 count={offset}")

    os.makedirs(OUT_DIR, exist_ok=True)
    run(f"cat kernel.bin ramdisk-new.gz > {OUT_DIR}/boot-new.img")

    os.chdir(BASE)
    input("\n✔ boot-new.img created in ./out — ENTER")

# ---------- VBMETA ----------

def disable_vbmeta():
    original = input("Path to original vbmeta.img: ").strip()
    if not os.path.isfile(original):
        print("vbmeta.img not found")
        return

    size = os.path.getsize(original)
    os.makedirs(OUT_DIR, exist_ok=True)

    out = os.path.join(OUT_DIR, "vbmeta-new.img")
    with open(out, "wb") as f:
        f.write(b"\x00" * size)

    print(f"\n✔ vbmeta-new.img created ({size} bytes)")
    print("✔ AVB verification disabled")
    input("ENTER to continue")

# ---------- MAIN ----------

while True:
    menu()
    choice = input("> ").strip().lower()

    if choice == "1":
        extract_boot()
    elif choice == "2":
        repack_boot()
    elif choice == "3":
        disable_vbmeta()
    elif choice == "q":
        break
