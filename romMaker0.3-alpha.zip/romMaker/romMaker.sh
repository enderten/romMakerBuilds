#!/bin/bash

set -e

BASE_DIR="$(pwd)"
GSI_DIR="$BASE_DIR/gsi"
MOUNT_DIR="$BASE_DIR/mount"
NEW_DIR="$BASE_DIR/new"
OUT_DIR="$BASE_DIR/out"
BOOT_DIR="$BASE_DIR/boot"

menu() {
    clear
    echo "RomMaker-GSI Extractor"
    echo "----------------------"
    echo "[1] Extract SYSTEM.img"
    echo "[2] Make system-new.img"
    echo "[3] Extract BOOT.img"
    echo "[4] Repack BOOT.img"
    echo "[5] Disable VBMeta (no verification)"
    echo "[q] Exit"
    echo
    read -p "> " opt
}

extract_system() {
    read -p "Path to system.img (EXT4): " IMG
    [ ! -f "$IMG" ] && echo "system.img not found" && exit 1

    mkdir -p "$GSI_DIR" "$MOUNT_DIR"

    sudo e2fsck -f "$IMG"
    sudo mount -o loop "$IMG" "$MOUNT_DIR"
    sudo cp -a "$MOUNT_DIR/." "$GSI_DIR/"
    sudo chown -R "$USER:$USER" "$GSI_DIR"
    sudo umount "$MOUNT_DIR"

    read -p "✔ SYSTEM extracted — ENTER"
}

make_system() {
    mkdir -p "$OUT_DIR" "$NEW_DIR"
    OUT_IMG="$OUT_DIR/system-new.img"

    dd if=/dev/zero of="$OUT_IMG" bs=1M count=3890 status=progress
    mkfs.ext4 "$OUT_IMG"

    sudo mount -o loop "$OUT_IMG" "$NEW_DIR"
    sudo cp -a "$GSI_DIR/." "$NEW_DIR/"
    sync
    sudo umount "$NEW_DIR"

    sudo e2fsck -f "$OUT_IMG"
    sudo resize2fs "$OUT_IMG"

    read -p "✔ system-new.img created — ENTER"
}

extract_boot() {
    read -p "Path to boot.img: " IMG
    [ ! -f "$IMG" ] && echo "boot.img not found" && exit 1

    mkdir -p "$BOOT_DIR"
    cd "$BOOT_DIR"

    grep -abo $'\x1f\x8b\x08' "$IMG" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    dd if="$IMG" of=ramdisk.gz bs=1 skip="$OFFSET" status=progress
    mkdir -p ramdisk
    gzip -dc ramdisk.gz | (cd ramdisk && cpio -idmv)

    cd "$BASE_DIR"
    read -p "✔ BOOT extracted — ENTER"
}

repack_boot() {
    cd "$BOOT_DIR"
    find ramdisk | cpio -o -H newc | gzip > ramdisk-new.gz

    read -p "Path to original boot.img: " ORIGINAL
    [ ! -f "$ORIGINAL" ] && echo "boot.img not found" && exit 1

    grep -abo $'\x1f\x8b\x08' "$ORIGINAL" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    dd if="$ORIGINAL" of=kernel.bin bs=1 count="$OFFSET"

    mkdir -p "$OUT_DIR"
    cat kernel.bin ramdisk-new.gz > "$OUT_DIR/boot-new.img"

    cd "$BASE_DIR"
    read -p "✔ boot-new.img created — ENTER"
}

disable_vbmeta() {
    read -p "Path to original vbmeta.img: " ORIGINAL
    [ ! -f "$ORIGINAL" ] && echo "vbmeta.img not found" && exit 1

    SIZE=$(stat -c%s "$ORIGINAL")
    mkdir -p "$OUT_DIR"

    dd if=/dev/zero of="$OUT_DIR/vbmeta-new.img" bs=1 count="$SIZE" status=none

    echo
    echo "✔ vbmeta-new.img created ($SIZE bytes)"
    echo "✔ AVB verification disabled"
    read -p "ENTER to continue"
}

while true; do
    menu
    case "$opt" in
        1) extract_system ;;
        2) make_system ;;
        3) extract_boot ;;
        4) repack_boot ;;
        5) disable_vbmeta ;;
        q) exit 0 ;;
        *) echo "Invalid option"; sleep 1 ;;
    esac
done
