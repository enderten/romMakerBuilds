#!/bin/bash

set -e

BASE_DIR="$(pwd)"
GSI_DIR="$BASE_DIR/gsi"
MOUNT_DIR="$BASE_DIR/mount"
NEW_DIR="$BASE_DIR/new"
OUT_DIR="$BASE_DIR/out"
BOOT_DIR="$BASE_DIR/boot"

clear

menu() {
    clear
    echo "RomMaker-GSI Extractor"
    echo "----------------------"
    echo "[1] Extract SYSTEM.img"
    echo "[2] Make system-new.img"
    echo "[3] Extract BOOT.img"
    echo "[4] Repack BOOT.img"
    echo "[q] Exit"
    echo
    read -p "> " opt
}

extract_system() {
    read -p "Path to system.img (EXT4): " IMG
    [ ! -f "$IMG" ] && echo "system.img not found" && exit 1

    mkdir -p "$GSI_DIR" "$MOUNT_DIR"

    sudo e2fsck -f "$IMG"
    sudo mount -o loop "$IMG" "$MOUNT_DIR"
    sudo cp -a "$MOUNT_DIR/." "$GSI_DIR/"
    sudo chown -R "$USER:$USER" "$GSI_DIR"
    sudo umount "$MOUNT_DIR"

    read -p "✔ SYSTEM extracted to ./gsi — ENTER"
}

make_system() {
    mkdir -p "$OUT_DIR" "$NEW_DIR"
    OUT_IMG="$OUT_DIR/system-new.img"

    dd if=/dev/zero of="$OUT_IMG" bs=1M count=3890 status=progress
    mkfs.ext4 "$OUT_IMG"

    sudo mount -o loop "$OUT_IMG" "$NEW_DIR"
    sudo cp -a "$GSI_DIR/." "$NEW_DIR/"
    sync
    sudo umount "$NEW_DIR"

    sudo e2fsck -f "$OUT_IMG"
    sudo resize2fs "$OUT_IMG"

    read -p "✔ system-new.img created — ENTER"
}

extract_boot() {
    read -p "Path to boot.img: " IMG
    [ ! -f "$IMG" ] && echo "boot.img not found" && exit 1

    mkdir -p "$BOOT_DIR"
    cd "$BOOT_DIR"

    grep -abo $'\x1f\x8b\x08' "$IMG" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    [ -z "$OFFSET" ] && echo "No gzip ramdisk found" && exit 1

    dd if="$IMG" of=ramdisk.gz bs=1 skip="$OFFSET" status=progress

    mkdir -p ramdisk
    gzip -dc ramdisk.gz | (cd ramdisk && cpio -idmv)

    cd "$BASE_DIR"
    read -p "✔ BOOT ramdisk extracted to ./boot/ramdisk — ENTER"
}

repack_boot() {
    [ ! -d "$BOOT_DIR/ramdisk" ] && echo "No ramdisk directory found" && exit 1

    cd "$BOOT_DIR"

    find ramdisk | cpio -o -H newc | gzip > ramdisk-new.gz

    read -p "Path to original boot.img: " ORIGINAL
    [ ! -f "$ORIGINAL" ] && echo "Original boot.img not found" && exit 1

    grep -abo $'\x1f\x8b\x08' "$ORIGINAL" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    dd if="$ORIGINAL" of=kernel.bin bs=1 count="$OFFSET"

    mkdir -p "$OUT_DIR"
    cat kernel.bin ramdisk-new.gz > "$OUT_DIR/boot-new.img"

    cd "$BASE_DIR"
    read -p "✔ boot-new.img created in ./out — ENTER"
}

while true; do
    menu
    case "$opt" in
        1) extract_system ;;
        2) make_system ;;
        3) extract_boot ;;
        4) repack_boot ;;
        q) exit 0 ;;
        *) echo "Invalid option"; sleep 1 ;;
    esac
done