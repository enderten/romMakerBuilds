import os
import sys
import subprocess

BASE_DIR = os.getcwd()
GSI_DIR = os.path.join(BASE_DIR, "gsi")
MOUNT_DIR = os.path.join(BASE_DIR, "mount")
NEW_DIR = os.path.join(BASE_DIR, "new")
OUT_DIR = os.path.join(BASE_DIR, "out")

def run(cmd):
    print(f"> {cmd}")
    ret = os.system(cmd)
    if ret != 0:
        print("Error ejecutando comando")
        sys.exit(1)

def clear():
    os.system("clear")

def menu():
    clear()
    print("RomMaker-GSI Extractor")
    print("----------------------")
    print("[1] Extract")
    print("[2] Make .IMG")
    print("[q] Exit\n")

def extract():
    img = input("Ruta del system.img (EXT4): ").strip()

    if not os.path.isfile(img):
        print("IMG no encontrado")
        return

    os.makedirs(GSI_DIR, exist_ok=True)
    os.makedirs(MOUNT_DIR, exist_ok=True)

    run(f"sudo e2fsck -f {img}")
    run(f"sudo mount -o loop {img} {MOUNT_DIR}")
    run(f"sudo cp -a {MOUNT_DIR}/. {GSI_DIR}/")
    run(f"sudo chown -R $USER:$USER {GSI_DIR}")
    run(f"sudo umount {MOUNT_DIR}")

    print("\n✔ Extract terminado")
    input("ENTER para continuar")

def make_img():
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(NEW_DIR, exist_ok=True)

    out_img = os.path.join(OUT_DIR, "system-new.img")

    run(f"dd if=/dev/zero of={out_img} bs=1M count=3890 status=progress")
    run(f"mkfs.ext4 {out_img}")
    run(f"sudo mount -o loop {out_img} {NEW_DIR}")
    run(f"sudo cp -a {GSI_DIR}/. {NEW_DIR}/")
    run("sync")
    run(f"sudo umount {NEW_DIR}")
    run(f"sudo e2fsck -f {out_img}")
    run(f"sudo resize2fs {out_img}")

    print("\n✔ system-new.img creado en ./out")
    input("ENTER para continuar")

# -------- MAIN --------
while True:
    menu()
    opt = input("> ").strip().lower()

    if opt == "1":
        extract()
    elif opt == "2":
        make_img()
    elif opt == "q":
        break
    else:
        print("Opción inválida")
