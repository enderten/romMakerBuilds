import os
import sys

BASE = os.getcwd()
GSI_DIR = os.path.join(BASE, "gsi")
MOUNT_DIR = os.path.join(BASE, "mount")
NEW_DIR = os.path.join(BASE, "new")
OUT_DIR = os.path.join(BASE, "out")
BOOT_DIR = os.path.join(BASE, "boot")

def run(cmd):
    print(f"> {cmd}")
    if os.system(cmd) != 0:
        print("ERROR executing command")
        sys.exit(1)

def clear():
    os.system("clear")

def menu():
    clear()
    print("RomMaker-GSI Extractor")
    print("----------------------")
    print("[1] Extract SYSTEM.img")
    print("[2] Make system-new.img")
    print("[3] Extract BOOT.img")
    print("[4] Repack BOOT.img")
    print("[q] Exit\n")

# ---------------- SYSTEM ----------------

def extract_system():
    img = input("Path to system.img (EXT4): ").strip()
    if not os.path.isfile(img):
        print("system.img not found")
        return

    os.makedirs(GSI_DIR, exist_ok=True)
    os.makedirs(MOUNT_DIR, exist_ok=True)

    run(f"sudo e2fsck -f {img}")
    run(f"sudo mount -o loop {img} {MOUNT_DIR}")
    run(f"sudo cp -a {MOUNT_DIR}/. {GSI_DIR}/")
    run(f"sudo chown -R $USER:$USER {GSI_DIR}")
    run(f"sudo umount {MOUNT_DIR}")

    input("\n✔ SYSTEM extracted into ./gsi — ENTER")

def make_system():
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(NEW_DIR, exist_ok=True)

    out_img = os.path.join(OUT_DIR, "system-new.img")

    run(f"dd if=/dev/zero of={out_img} bs=1M count=3890 status=progress")
    run(f"mkfs.ext4 {out_img}")
    run(f"sudo mount -o loop {out_img} {NEW_DIR}")
    run(f"sudo cp -a {GSI_DIR}/. {NEW_DIR}/")
    run("sync")
    run(f"sudo umount {NEW_DIR}")
    run(f"sudo e2fsck -f {out_img}")
    run(f"sudo resize2fs {out_img}")

    input("\n✔ system-new.img created in ./out — ENTER")

# ---------------- BOOT ----------------

def extract_boot():
    img = input("Path to boot.img: ").strip()
    if not os.path.isfile(img):
        print("boot.img not found")
        return

    os.makedirs(BOOT_DIR, exist_ok=True)
    os.chdir(BOOT_DIR)

    # find gzip ramdisk offset
    run(f"grep -abo $'\\x1f\\x8b\\x08' {img} | head -n1 > offset.txt")
    with open("offset.txt") as f:
        offset = f.read().split(":")[0].strip()

    if not offset.isdigit():
        print("No gzip ramdisk found")
        sys.exit(1)

    run(f"dd if={img} of=ramdisk.gz bs=1 skip={offset} status=progress")

    run("mkdir -p ramdisk")
    run("gzip -dc ramdisk.gz | (cd ramdisk && cpio -idmv)")

    os.chdir(BASE)
    input("\n✔ BOOT ramdisk extracted into ./boot/ramdisk — ENTER")

def repack_boot():
    if not os.path.isdir(os.path.join(BOOT_DIR, "ramdisk")):
        print("No ramdisk directory found. Extract boot.img first.")
        return

    os.chdir(BOOT_DIR)

    print("[*] Packing ramdisk")
    run("find ramdisk | cpio -o -H newc | gzip > ramdisk-new.gz")

    print("[*] Creating new boot.img (ramdisk only)")
    print("NOTE: Kernel is reused as-is from original boot.img")

    original = input("Path to original boot.img: ").strip()
    if not os.path.isfile(original):
        print("Original boot.img not found")
        sys.exit(1)

    # extract kernel (everything before ramdisk)
    run(f"grep -abo $'\\x1f\\x8b\\x08' {original} | head -n1 > offset.txt")
    with open("offset.txt") as f:
        offset = int(f.read().split(":")[0].strip())

    run(f"dd if={original} of=kernel.bin bs=1 count={offset}")

    # concatenate kernel + new ramdisk
    out_boot = os.path.join(OUT_DIR, "boot-new.img")
    os.makedirs(OUT_DIR, exist_ok=True)

    run(f"cat kernel.bin ramdisk-new.gz > {out_boot}")

    os.chdir(BASE)
    input("\n✔ boot-new.img created in ./out — ENTER")

# ---------------- MAIN ----------------

while True:
    menu()
    choice = input("> ").strip().lower()

    if choice == "1":
        extract_system()
    elif choice == "2":
        make_system()
    elif choice == "3":
        extract_boot()
    elif choice == "4":
        repack_boot()
    elif choice == "q":
        break