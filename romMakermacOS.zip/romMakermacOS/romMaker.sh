#!/bin/zsh

BASE_DIR="$(pwd)"
BOOT_DIR="$BASE_DIR/boot"
OUT_DIR="$BASE_DIR/out"

menu() {
    clear
    echo "RomMaker macOS (Limited)"
    echo "------------------------"
    echo "[1] Disable VBMeta (no verification)"
    echo "[q] Exit"
    echo
    read -p "> " opt
}

extract_boot() {
    read -p "Path to boot.img: " IMG
    [ ! -f "$IMG" ] && echo "boot.img not found" && return

    mkdir -p "$BOOT_DIR"
    cd "$BOOT_DIR"

    grep -abo $'\x1f\x8b\x08' "$IMG" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    dd if="$IMG" of=ramdisk.gz bs=1 skip="$OFFSET"
    mkdir -p ramdisk
    gzip -dc ramdisk.gz | (cd ramdisk && cpio -idmv)

    cd "$BASE_DIR"
    read -p "✔ BOOT extracted — ENTER"
}

repack_boot() {
    cd "$BOOT_DIR" || return
    find ramdisk | cpio -o -H newc | gzip > ramdisk-new.gz

    read -p "Path to original boot.img: " ORIGINAL
    [ ! -f "$ORIGINAL" ] && echo "boot.img not found" && return

    grep -abo $'\x1f\x8b\x08' "$ORIGINAL" | head -n1 > offset.txt
    OFFSET=$(cut -d: -f1 offset.txt)

    dd if="$ORIGINAL" of=kernel.bin bs=1 count="$OFFSET"

    mkdir -p "$OUT_DIR"
    cat kernel.bin ramdisk-new.gz > "$OUT_DIR/boot-new.img"

    cd "$BASE_DIR"
    read -p "✔ boot-new.img created — ENTER"
}

disable_vbmeta() {
    read -p "Path to original vbmeta.img: " ORIGINAL
    [ ! -f "$ORIGINAL" ] && echo "vbmeta.img not found" && return

    SIZE=$(stat -f%z "$ORIGINAL")
    mkdir -p "$OUT_DIR"

    dd if=/dev/zero of="$OUT_DIR/vbmeta-new.img" bs=1 count="$SIZE" status=none

    echo
    echo "✔ vbmeta-new.img created ($SIZE bytes)"
    echo "✔ AVB verification disabled"
    read -p "ENTER to continue"
}

while true; do
    menu
    case "$opt" in
        1) extract_boot ;;
        2) repack_boot ;;
        3) disable_vbmeta ;;
        q) exit 0 ;;
        *) echo "Invalid option"; sleep 1 ;;
    esac
done
